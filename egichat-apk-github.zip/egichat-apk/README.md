# EGICHAT APK
Push ke GitHub -> tab **Actions** -> workflow **Build APK** jalan otomatis.
APK ada di **Releases** (atau Artifacts di run tersebut).
